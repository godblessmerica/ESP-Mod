package com.playeresp.client.mixin;

import com.playeresp.client.ESPConfig;
import com.playeresp.client.EntitySettings;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public class EntityMixin {

    @Inject(method = "isCurrentlyGlowing", at = @At("HEAD"), cancellable = true)
    private void forceGlowing(CallbackInfoReturnable<Boolean> cir) {
        if (!ESPConfig.enabled) return;

        Entity self = (Entity) (Object) this;
        Minecraft client = Minecraft.getInstance();
        if (client.player == null || self == client.player) return;

        EntitySettings override = ESPConfig.getOverride(self);

        if (override != null) {
            if (override.enabled && override.showOutline) cir.setReturnValue(true);
        } else {
            boolean typeMatch = ESPConfig.allEntityESP
                || (ESPConfig.mobESP    && self instanceof Mob)
                || (ESPConfig.playerESP && self instanceof Player);
            if (typeMatch && ESPConfig.showOutline) cir.setReturnValue(true);
        }
    }
}
