package com.playeresp.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.network.chat.Component;
import com.mojang.blaze3d.platform.InputConstants;
import org.lwjgl.glfw.GLFW;

public class PlayerESPClient implements ClientModInitializer {

    public static KeyMapping toggleKey;

    @Override
    public void onInitializeClient() {
        ESPConfig.load();

        toggleKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
            "key.playeresp.toggle",
            InputConstants.Type.KEYSYM,
            GLFW.GLFW_KEY_G,
            KeyMapping.Category.MISC
        ));

        HitboxRenderer.register();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.consumeClick()) {
                ESPConfig.enabled = !ESPConfig.enabled;
                if (client.player != null) {
                    client.player.sendOverlayMessage(
                        Component.literal("ESP " + (ESPConfig.enabled ? "§aON" : "§cOFF"))
                    );
                }
            }
        });
    }
}
