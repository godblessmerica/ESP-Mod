package com.playeresp.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractSelectionList;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.CycleButton;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class AdvancedESPScreen extends Screen {

    private final Screen parent;
    private EntityList list;
    private EditBox searchBox;
    private final List<EntityType<?>> allTypes = new ArrayList<>();

    enum Cat {
        PLAYERS    ("Players"),
        MOBS       ("Mobs"),
        VEHICLES   ("Vehicles  (boats, minecarts)"),
        DECORATIVE ("Decorative  (armor stands, frames)"),
        PROJECTILES("Projectiles"),
        ITEMS      ("Items & Drops"),
        TECHNICAL  ("Technical  (internal / rarely needed)"),
        OTHER      ("Other");

        final String label;
        Cat(String label) { this.label = label; }
    }

    private static Cat categorize(EntityType<?> type) {
        if (type == EntityType.PLAYER) return Cat.PLAYERS;

        MobCategory mc = type.getCategory();
        if (mc != MobCategory.MISC) return Cat.MOBS;

        String p = EntityType.getKey(type).toString();

        // Technical / internal entities
        if (p.contains("area_effect_cloud") || p.contains("marker")    ||
            p.contains("interaction")       || p.contains("_display")  ||
            p.contains("lightning")         || p.contains("falling_block") ||
            p.contains("end_crystal")       || p.contains("end_gateway"))
            return Cat.TECHNICAL;

        if (p.contains("boat") || p.contains("raft") || p.contains("minecart"))
            return Cat.VEHICLES;

        if (p.contains("armor_stand") || p.contains("item_frame") ||
            p.contains("painting")    || p.contains("lead_knot"))
            return Cat.DECORATIVE;

        if (p.contains("arrow")          || p.contains("fireball")      ||
            p.contains("snowball")       || p.contains("egg")           ||
            p.contains("ender_pearl")    || p.contains("trident")       ||
            p.contains("potion")         || p.contains("firework")      ||
            p.contains("fishing")        || p.contains("shulker_bullet")||
            p.contains("wind_charge")    || p.contains("wither_skull"))
            return Cat.PROJECTILES;

        if (p.contains("item")       || p.contains("experience") ||
            p.contains("xp_orb"))
            return Cat.ITEMS;

        return Cat.OTHER;
    }

    public AdvancedESPScreen(Screen parent) {
        super(Minecraft.getInstance(), Minecraft.getInstance().font,
            Component.literal("Advanced Entity Settings"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        if (allTypes.isEmpty()) {
            for (EntityType<?> t : BuiltInRegistries.ENTITY_TYPE) allTypes.add(t);
            allTypes.sort(Comparator.comparing(t -> t.getDescription().getString().toLowerCase()));
        }

        int searchW = Math.min(300, this.width - 40);
        searchBox = new EditBox(this.font, this.width / 2 - searchW / 2, 36, searchW, 16,
            Component.literal("Search..."));
        searchBox.setMaxLength(50);
        searchBox.setHint(Component.literal("Search..."));
        searchBox.setResponder(this::rebuild);
        addRenderableWidget(searchBox);

        list = new EntityList(this.minecraft, this.width, this.height - 80, 58, 22);
        list.setX(0);
        addRenderableWidget(list);
        rebuild("");

        addRenderableWidget(Button.builder(Component.literal("Done"),
                btn -> { ESPConfig.save(); this.minecraft.setScreen(parent); })
            .bounds(this.width / 2 - 75, this.height - 26, 150, 20).build());
    }

    private void rebuild(String filter) {
        list.clearAll();
        String q = filter.toLowerCase();

        Map<Cat, List<EntityType<?>>> groups = new LinkedHashMap<>();
        for (Cat c : Cat.values()) groups.put(c, new ArrayList<>());

        for (EntityType<?> t : allTypes) {
            String name = t.getDescription().getString().toLowerCase();
            String id   = EntityType.getKey(t).toString().toLowerCase();
            if (q.isEmpty() || name.contains(q) || id.contains(q))
                groups.get(categorize(t)).add(t);
        }

        for (Map.Entry<Cat, List<EntityType<?>>> entry : groups.entrySet()) {
            if (entry.getValue().isEmpty()) continue;
            list.addEntry(new EntityList.Header(entry.getKey().label));
            for (EntityType<?> t : entry.getValue())
                list.addEntry(new EntityList.Row(t));
        }
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float delta) {
        super.extractRenderState(g, mx, my, delta);
        g.centeredText(this.font, "Advanced Entity Settings", this.width / 2, 10, 0xFFFFFF);
        g.centeredText(this.font, "Yellow name = has override", this.width / 2, 22, 0xAAAAAA);
    }

    @Override
    public void onClose() { ESPConfig.save(); this.minecraft.setScreen(parent); }

    // ─────────────────────────────────────────────────────────────────

    static class EntityList extends AbstractSelectionList<EntityList.BaseEntry> {
        EntityList(Minecraft mc, int w, int h, int y, int ih) { super(mc, w, h, y, ih); }
        @Override public int addEntry(BaseEntry e) { return super.addEntry(e); }
        public void clearAll() { clearEntries(); }
        @Override protected void updateWidgetNarration(NarrationElementOutput o) {}

        static class Header extends BaseEntry {
            private final Button btn;

            Header(String t) {
                this.btn = Button.builder(Component.literal("— " + t + " —"), b -> {})
                    .bounds(0, 0, 200, 18).build();
                this.btn.active = false;
            }

            @Override
            public void extractContent(GuiGraphicsExtractor g, int mx, int my, boolean hovered, float delta) {
                int cx = getContentX(), cy = getContentY(), w = getContentWidth(), h = getContentHeight();
                btn.setX(cx);
                btn.setY(cy);
                btn.setWidth(w);
                btn.setHeight(h);
                btn.extractRenderState(g, mx, my, delta);
            }
            @Override public boolean mouseClicked(MouseButtonEvent e, boolean bl) { return false; }
        }

        static class Row extends BaseEntry {
            private final EntityType<?> type;
            private final String typeId;
            private final String name;
            private final CycleButton<Boolean> btn;

            private static final int BTN_W   = 65;
            private static final int BTN_GAP = 6;
            private static final int LEFT_PAD = 12;

            Row(EntityType<?> type) {
                this.type   = type;
                this.typeId = EntityType.getKey(type).toString();
                this.name   = type.getDescription().getString();

                this.btn = CycleButton.<Boolean>builder(
                        val -> val ? Component.literal("Show").withStyle(s -> s.withColor(0x55FF55))
                                   : Component.literal("Hide").withStyle(s -> s.withColor(0xFF5555)),
                        effectiveEnabled())
                    .withValues(List.of(true, false))
                    .displayOnlyValue()
                    .create(0, 0, BTN_W, 20, Component.empty(), (b, val) -> {
                        EntitySettings ov = ESPConfig.entityOverrides.get(typeId);
                        if (ov != null) {
                            ov.enabled = val;
                        } else {
                            ESPConfig.entityOverrides.put(typeId,
                                new EntitySettings(val, ESPConfig.showOutline, ESPConfig.showHitbox));
                        }
                        ESPConfig.save();
                    });
            }

            private boolean effectiveEnabled() {
                EntitySettings ov = ESPConfig.entityOverrides.get(typeId);
                if (ov != null) return ov.enabled;
                if (ESPConfig.allEntityESP) return true;
                if (type == EntityType.PLAYER) return ESPConfig.playerESP;
                if (type.getCategory() != MobCategory.MISC) return ESPConfig.mobESP;
                return false;
            }

            @Override
            public void extractContent(GuiGraphicsExtractor g, int mx, int my, boolean hovered, float delta) {
                int cx = getContentX(), cy = getContentY(), w = getContentWidth(), h = getContentHeight();
                var font = Minecraft.getInstance().font;
                boolean hasOv = ESPConfig.entityOverrides.containsKey(typeId);

                // Dark fill so text is readable over blurred background
                g.fill(cx, cy, cx + w, cy + h, 0x88000000);

                btn.setValue(effectiveEnabled());
                btn.setX(cx + w - BTN_W - BTN_GAP);
                btn.setY(cy + 1);
                btn.setWidth(BTN_W);
                btn.setHeight(h - 2);

                // Truncate name if it would overlap the button
                int maxTextW = w - BTN_W - BTN_GAP - LEFT_PAD - 8;
                String display = name;
                if (font.width(display) > maxTextW)
                    display = font.plainSubstrByWidth(display, maxTextW - font.width("...")) + "...";

                g.text(font, display, cx + LEFT_PAD, cy + (h - 8) / 2, 0xFFFFFFFF, true);

                btn.extractRenderState(g, mx, my, delta);
            }

            @Override
            public boolean mouseClicked(MouseButtonEvent e, boolean bl) {
                return btn.mouseClicked(e, bl);
            }
        }

        abstract static class BaseEntry extends AbstractSelectionList.Entry<BaseEntry> {
            @Override public abstract void extractContent(GuiGraphicsExtractor g, int mx, int my, boolean hovered, float delta);
            @Override public abstract boolean mouseClicked(MouseButtonEvent e, boolean bl);
        }
    }
}
