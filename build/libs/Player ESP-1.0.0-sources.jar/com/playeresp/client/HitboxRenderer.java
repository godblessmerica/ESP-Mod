package com.playeresp.client;

import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.gizmos.GizmoStyle;
import net.minecraft.gizmos.Gizmos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public class HitboxRenderer {

    private static final int COLOR_PLAYER = 0xFFFF5555;
    private static final int COLOR_MOB    = 0xFFFFAA00;
    private static final int COLOR_ENTITY = 0xFFFFFF55;

    public static void register() {
        LevelRenderEvents.BEFORE_GIZMOS.register(context -> {
            if (!ESPConfig.enabled) return;

            Minecraft mc = Minecraft.getInstance();
            if (mc.level == null || mc.player == null) return;

            // Gizmos expect camera-relative coordinates, same as vanilla debug renderers
            Vec3 cam = mc.gameRenderer.getMainCamera().position();

            try (var collection = context.levelRenderer().collectPerFrameGizmos()) {
                for (Entity entity : mc.level.entitiesForRendering()) {
                    if (entity == mc.player) continue;

                    EntitySettings override = ESPConfig.getOverride(entity);
                    boolean shouldDraw;
                    boolean useHitbox;

                    if (override != null) {
                        shouldDraw = override.enabled;
                        useHitbox  = override.showHitbox;
                    } else {
                        shouldDraw = ESPConfig.allEntityESP
                            || (ESPConfig.mobESP    && entity instanceof Mob)
                            || (ESPConfig.playerESP && entity instanceof Player);
                        useHitbox = ESPConfig.showHitbox;
                    }

                    if (!shouldDraw || !useHitbox) continue;

                    int color;
                    if (entity instanceof Player)   color = COLOR_PLAYER;
                    else if (entity instanceof Mob) color = COLOR_MOB;
                    else                            color = COLOR_ENTITY;

                    // Offset AABB to camera-relative space
                    AABB box = entity.getBoundingBox().move(-cam.x, -cam.y, -cam.z);

                    Gizmos.cuboid(box, GizmoStyle.stroke(color)).setAlwaysOnTop();
                }
            }
        });
    }
}
