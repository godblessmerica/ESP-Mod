package com.playeresp.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractSelectionList;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.CycleButton;
import net.minecraft.client.gui.layouts.HeaderAndFooterLayout;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.options.controls.KeyBindsScreen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

public class ESPConfigScreen extends Screen {

    private final Screen parent;
    public final HeaderAndFooterLayout layout = new HeaderAndFooterLayout(this);

    public ESPConfigScreen(Screen parent) {
        super(Minecraft.getInstance(), Minecraft.getInstance().font, Component.literal("Spectral ESP"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        // Title in header, Done in footer — exactly how Mod Menu does it
        layout.addTitleHeader(Component.literal("Spectral ESP"), this.font);

        Button doneBtn = layout.addToFooter(Button.builder(Component.literal("Done"),
            btn -> { ESPConfig.save(); this.minecraft.setScreen(parent); })
            .width(200).build());

        layout.arrangeElements();
        addRenderableWidget(doneBtn);

        // Content list fills the space between header and footer
        SettingsList list = new SettingsList(this.minecraft, this.width,
            layout.getContentHeight(), layout.getHeaderHeight(), 22);
        list.setX(0);

        list.addEntry(new SettingsList.HeaderEntry("ESP Display"));
        list.addEntry(new SettingsList.ToggleEntry("Show Outline (glow)",
            () -> ESPConfig.showOutline, v -> ESPConfig.showOutline = v));
        list.addEntry(new SettingsList.ToggleEntry("Show Hitbox (box)",
            () -> ESPConfig.showHitbox, v -> ESPConfig.showHitbox = v));

        list.addEntry(new SettingsList.HeaderEntry("Entities"));
        list.addEntry(new SettingsList.ToggleEntry("Players",
            () -> ESPConfig.playerESP, v -> ESPConfig.playerESP = v));
        list.addEntry(new SettingsList.ToggleEntry("Mobs",
            () -> ESPConfig.mobESP, v -> ESPConfig.mobESP = v));
        list.addEntry(new SettingsList.ToggleEntry("All Entities",
            () -> ESPConfig.allEntityESP, v -> ESPConfig.allEntityESP = v));
        list.addEntry(new SettingsList.ButtonEntry("Advanced Entity Settings...",
            () -> this.minecraft.setScreen(new AdvancedESPScreen(this))));

        list.addEntry(new SettingsList.HeaderEntry("Controls"));
        list.addEntry(new SettingsList.ButtonEntry("Change Keybind...",
            () -> this.minecraft.setScreen(new KeyBindsScreen(this, this.minecraft.options))));

        addRenderableWidget(list);
    }

    @Override
    public void onClose() { ESPConfig.save(); this.minecraft.setScreen(parent); }

    // ─────────────────────────────────────────────────────────────────

    static class SettingsList extends AbstractSelectionList<SettingsList.BaseEntry> {
        SettingsList(Minecraft mc, int w, int h, int y, int ih) { super(mc, w, h, y, ih); }
        @Override public int addEntry(BaseEntry e) { return super.addEntry(e); }
        @Override protected void updateWidgetNarration(NarrationElementOutput o) {}

        // ── Section header — plain text only, no button ──────────────
        static class HeaderEntry extends BaseEntry {
            private final String title;
            HeaderEntry(String t) { this.title = t; }

            @Override
            public void extractContent(GuiGraphicsExtractor g, int mx, int my, boolean hovered, float delta) {
                int cx = getContentX(), cy = getContentY(), w = getContentWidth(), h = getContentHeight();
                g.text(Minecraft.getInstance().font, title, cx + 6, cy + (h - 8) / 2, 0xAAAAAA, true);
            }
            @Override public boolean mouseClicked(MouseButtonEvent e, boolean bl) { return false; }
        }

        // ── Toggle row ───────────────────────────────────────────────
        static class ToggleEntry extends BaseEntry {
            private final String label;
            private final BooleanSupplier getter;
            private final Consumer<Boolean> setter;
            private final CycleButton<Boolean> btn;

            ToggleEntry(String label, BooleanSupplier getter, Consumer<Boolean> setter) {
                this.label  = label;
                this.getter = getter;
                this.setter = setter;
                this.btn = CycleButton.<Boolean>builder(
                        val -> val ? Component.literal("Show").withStyle(s -> s.withColor(0x55FF55))
                                   : Component.literal("Hide").withStyle(s -> s.withColor(0xFF5555)),
                        getter.getAsBoolean())
                    .withValues(List.of(true, false))
                    .displayOnlyValue()
                    .create(0, 0, 65, 20, Component.empty(),
                        (b, val) -> { setter.accept(val); ESPConfig.save(); });
            }

            @Override
            public void extractContent(GuiGraphicsExtractor g, int mx, int my, boolean hovered, float delta) {
                int cx = getContentX(), cy = getContentY(), w = getContentWidth(), h = getContentHeight();
                var font = Minecraft.getInstance().font;

                g.fill(cx, cy, cx + w, cy + h, 0x88000000);

                btn.setValue(getter.getAsBoolean());
                btn.setX(cx + w - 71);
                btn.setY(cy + 1);
                btn.setWidth(65);
                btn.setHeight(h - 2);

                g.text(font, label, cx + 6, cy + (h - 8) / 2, 0xFFFFFF, true);
                btn.extractRenderState(g, mx, my, delta);
            }

            @Override
            public boolean mouseClicked(MouseButtonEvent e, boolean bl) {
                return btn.mouseClicked(e, bl);
            }
        }

        // ── Full-width button ────────────────────────────────────────
        static class ButtonEntry extends BaseEntry {
            private final Button btn;

            ButtonEntry(String label, Runnable action) {
                this.btn = Button.builder(Component.literal(label), b -> action.run())
                    .bounds(0, 0, 200, 20).build();
            }

            @Override
            public void extractContent(GuiGraphicsExtractor g, int mx, int my, boolean hovered, float delta) {
                int cx = getContentX(), cy = getContentY(), w = getContentWidth(), h = getContentHeight();
                btn.setX(cx + w / 2 - 100);
                btn.setY(cy + 1);
                btn.setWidth(200);
                btn.setHeight(h - 2);
                btn.extractRenderState(g, mx, my, delta);
            }

            @Override
            public boolean mouseClicked(MouseButtonEvent e, boolean bl) {
                return btn.mouseClicked(e, bl);
            }
        }

        abstract static class BaseEntry extends AbstractSelectionList.Entry<BaseEntry> {
            @Override public abstract void extractContent(GuiGraphicsExtractor g, int mx, int my, boolean hovered, float delta);
            @Override public abstract boolean mouseClicked(MouseButtonEvent e, boolean bl);
        }
    }
}
