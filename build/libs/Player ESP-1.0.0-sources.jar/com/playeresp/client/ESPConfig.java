package com.playeresp.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

public class ESPConfig {

    public static boolean enabled = false;

    // Global: which entity types to show (used when no per-entity override exists)
    public static boolean playerESP    = true;
    public static boolean mobESP       = false;
    public static boolean allEntityESP = false;

    // Global: what to render (used when no per-entity override exists)
    public static boolean showOutline = true;
    public static boolean showHitbox  = false;

    // Per-entity overrides — key is the entity type ID e.g. "minecraft:zombie"
    // If an entry exists here it takes priority over the global flags above
    public static Map<String, EntitySettings> entityOverrides = new HashMap<>();

    // Returns the override for this entity, or null if none (use global settings)
    public static EntitySettings getOverride(Entity entity) {
        String key = EntityType.getKey(entity.getType()).toString();
        return entityOverrides.get(key);
    }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH = FabricLoader.getInstance()
            .getConfigDir().resolve("playeresp.json");

    public static void load() {
        if (!Files.exists(CONFIG_PATH)) {
            save();
            return;
        }
        try (Reader reader = Files.newBufferedReader(CONFIG_PATH)) {
            Data data = GSON.fromJson(reader, Data.class);
            if (data != null) {
                playerESP       = data.playerESP;
                mobESP          = data.mobESP;
                allEntityESP    = data.allEntityESP;
                showOutline     = data.showOutline;
                showHitbox      = data.showHitbox;
                if (data.entityOverrides != null) entityOverrides = data.entityOverrides;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void save() {
        try (Writer writer = Files.newBufferedWriter(CONFIG_PATH)) {
            GSON.toJson(new Data(), writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static class Data {
        boolean playerESP    = ESPConfig.playerESP;
        boolean mobESP       = ESPConfig.mobESP;
        boolean allEntityESP = ESPConfig.allEntityESP;
        boolean showOutline  = ESPConfig.showOutline;
        boolean showHitbox   = ESPConfig.showHitbox;
        Map<String, EntitySettings> entityOverrides = ESPConfig.entityOverrides;
    }
}
